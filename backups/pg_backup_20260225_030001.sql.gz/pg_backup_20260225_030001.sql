--
-- PostgreSQL database dump
--

\restrict 6vZ6iekleMzCJPlkHYuBf6h1mhh5qiSkIkMQjhi2WYyO4SSCAhKAgdKh8L8hlnu

-- Dumped from database version 15.16
-- Dumped by pg_dump version 15.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: AuditEventType; Type: TYPE; Schema: public; Owner: mapeople
--

CREATE TYPE public."AuditEventType" AS ENUM (
    'LOGIN',
    'LOGOUT',
    'ACCESS_DENIED',
    'RESIDENT_CREATED',
    'RESIDENT_UPDATED',
    'RESIDENT_DELETED',
    'STATUS_CHANGED',
    'MESSAGE_SENT',
    'DATA_EXPORTED',
    'INVITE_SENT',
    'INVITE_ACCEPTED'
);


ALTER TYPE public."AuditEventType" OWNER TO mapeople;

--
-- Name: ResidentStatus; Type: TYPE; Schema: public; Owner: mapeople
--

CREATE TYPE public."ResidentStatus" AS ENUM (
    'NAO_CONTATADO',
    'CONTATADO',
    'AUSENTE',
    'RECUSOU',
    'INTERESSADO'
);


ALTER TYPE public."ResidentStatus" OWNER TO mapeople;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: mapeople
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'SUPERVISOR',
    'VOLUNTARIO'
);


ALTER TYPE public."Role" OWNER TO mapeople;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: mapeople
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "eventType" public."AuditEventType" NOT NULL,
    "userId" text NOT NULL,
    "residentId" text,
    metadata jsonb,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO mapeople;

--
-- Name: Message; Type: TABLE; Schema: public; Owner: mapeople
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "senderId" text NOT NULL,
    "receiverId" text NOT NULL,
    "encryptedContent" text NOT NULL,
    iv text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Message" OWNER TO mapeople;

--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: mapeople
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO mapeople;

--
-- Name: Resident; Type: TABLE; Schema: public; Owner: mapeople
--

CREATE TABLE public."Resident" (
    id text NOT NULL,
    "fullName" text NOT NULL,
    address text NOT NULL,
    lat double precision NOT NULL,
    lng double precision NOT NULL,
    phone text,
    notes text,
    status public."ResidentStatus" DEFAULT 'NAO_CONTATADO'::public."ResidentStatus" NOT NULL,
    "visitDate" timestamp(3) without time zone,
    "createdById" text NOT NULL,
    "updatedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Resident" OWNER TO mapeople;

--
-- Name: User; Type: TABLE; Schema: public; Owner: mapeople
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    image text,
    "googleId" text,
    role public."Role" DEFAULT 'VOLUNTARIO'::public."Role" NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "inviteToken" text,
    "inviteExpires" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO mapeople;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: mapeople
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO mapeople;

--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: mapeople
--

COPY public."AuditLog" (id, "eventType", "userId", "residentId", metadata, "ipAddress", "createdAt") FROM stdin;
cmlzvvugv0002t5lt12tkqzxn	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 00:45:09.245
cmlzw4r270001pi8ya6zeogn4	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 00:52:04.735
cmlzw6ybm000113sot3zbn45b	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 00:53:47.458
cmlzw7sef000313socglf5wb2	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 00:54:26.44
cmlzwfet400013ipydmo8e6fm	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:00:22.072
cmlzwh8bc00033ipyzt2k9ahl	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:01:46.968
cmlzwhygg00053ipyv6cquv53	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:02:20.848
cmlzwkqu400073ipy4nypxmdk	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:04:30.94
cmlzwzkt200014o5ar8n4o92y	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:16:02.964
cmlzx0v7l00034o5al70jyd3l	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:17:03.105
cmlzx3kr600054o5avdy8g8t3	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:19:09.521
cmlzx3ui500074o5a6qlhv4tl	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:19:22.156
cmlzxhi5f000158lmhwe0p0fg	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:29:59.329
cmlzxhqz0000358lm71tzi9sk	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:30:10.764
cmlzxjb8s000558lmg9lr6b7a	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:31:23.692
cmlzxjzem000758lmas8mzzpg	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:31:55.006
cmlzxui8b000958lmszad7d5u	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:40:05.963
cmlzy50za000b58lmcuvizoeo	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:48:16.821
cmlzy5par000d58lmhhehpypn	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 01:48:48.339
cmlzyoc9g000f58lmx7jxsny6	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 02:03:17.908
cmlzyokl8000h58lm4ugedvwp	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 02:03:28.701
cmlzypo2j000j58lmifkeb1dq	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 02:04:19.867
cmlzyqven000l58lmeobjiscu	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 02:05:16.031
cmlzyrnd6000n58lmw26qjul3	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 02:05:52.266
cmlzyuw8e000q58lm0yp7nal9	ACCESS_DENIED	cmlzyuw7s000o58lm3ddw4ajy	\N	{"reason": "Conta não aprovada"}	172.18.0.3	2026-02-24 02:08:23.726
cmlzyv49y000s58lmmtmdeal7	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 02:08:34.15
cmm14ai0d000u58lm749i7kl1	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 21:28:16.044
cmm14divs000w58lm1lgjmb9y	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 21:30:37.144
cmm14nqc3000y58lmyw4wt2z6	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 21:38:33.363
cmm14q9ee001058lmue3omz6k	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-24 21:40:31.382
cmm1ck6kk001258lmysukk90c	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 01:19:44.708
cmm1csssy001458lmw6r18afu	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 01:26:26.771
cmm1cvr2t001658lm8l0luncy	LOGOUT	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 01:28:44.501
cmm1cwce6001958lmn71f7ch3	ACCESS_DENIED	cmm1cwcd3001758lm45o8tqdi	\N	{"reason": "Conta não aprovada"}	172.18.0.3	2026-02-25 01:29:12.125
cmm1cwra4001b58lmti822p61	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 01:29:31.421
cmm1dbfch001d58lm0hue6rd0	LOGOUT	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 01:40:55.793
cmm1dbl6n001f58lm9j5glmsr	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 01:41:03.359
cmm1dx6ll001h58lmxx69m06t	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 01:57:50.889
cmm1e1jpg0001ayq3sv478mjx	LOGOUT	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:01:14.496
cmm1e1olj0003ayq3qfl4py6w	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:01:20.84
cmm1el9c10005ayq3atpwtw2p	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:16:34.176
cmm1elchz0007ayq3bhu6zse2	LOGOUT	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:16:38.278
cmm1er8i10009ayq3yp1gv4gx	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:21:13.034
cmm1erc51000bayq39rp7emga	LOGOUT	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:21:17.749
cmm1etcb5000dayq3o7mv8ahl	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:22:51.281
cmm1euks9000fayq3mspezr4p	LOGIN	cmlzvvufy0000t5lt3sa7iz7t	\N	\N	172.18.0.3	2026-02-25 02:23:48.921
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: mapeople
--

COPY public."Message" (id, "senderId", "receiverId", "encryptedContent", iv, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: mapeople
--

COPY public."RefreshToken" (id, token, "userId", "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Resident; Type: TABLE DATA; Schema: public; Owner: mapeople
--

COPY public."Resident" (id, "fullName", address, lat, lng, phone, notes, status, "visitDate", "createdById", "updatedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: mapeople
--

COPY public."User" (id, email, name, image, "googleId", role, "isActive", "inviteToken", "inviteExpires", "createdAt", "updatedAt") FROM stdin;
cmlzvvufy0000t5lt3sa7iz7t	carloseduardocostatj@gmail.com	Carlos Eduardo De Macedo Costa	https://lh3.googleusercontent.com/a/ACg8ocIqvA8OY7uUx498c-OC9jk2FugSNdo1RB4vH1fixgc70qKLGkDuwA=s96-c	100531099693171061817	ADMIN	t	\N	\N	2026-02-24 00:45:09.2	2026-02-24 00:45:09.2
cmlzyuw7s000o58lm3ddw4ajy	macedo.unifique@gmail.com	Carlos Eduardo De Macedo Costa	https://lh3.googleusercontent.com/a/ACg8ocKyCJ2hY111N3yJ7eGXL9NalQoqOsnsskEWJ_tAI0o5NjTkIg=s96-c	104017984501669034239	VOLUNTARIO	f	\N	\N	2026-02-24 02:08:23.69	2026-02-24 02:08:23.69
cmm1cwcd3001758lm45o8tqdi	cemc.contato@gmail.com	Carlos Eduardo de Macedo Costa	https://lh3.googleusercontent.com/a/ACg8ocI4uCKcNO3NxWDj5FDVfCpYNyAwPFZW5pHAEPACZF7ONNEZLS0_=s96-c	115412724487289558429	VOLUNTARIO	f	\N	\N	2026-02-25 01:29:12.087	2026-02-25 01:29:12.087
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: mapeople
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
07a9e986-7e0d-48ec-9897-04a469254ca8	b7ae2f97c973378aabce1a7374bf76b2ccba6a86d01a9fe4e664eb41b9c1a783	2026-02-23 19:47:50.777898+00	20260223173931_init	\N	\N	2026-02-23 19:47:50.611074+00	1
\.


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: Resident Resident_pkey; Type: CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."Resident"
    ADD CONSTRAINT "Resident_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_eventType_idx; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE INDEX "AuditLog_eventType_idx" ON public."AuditLog" USING btree ("eventType");


--
-- Name: AuditLog_userId_idx; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE INDEX "AuditLog_userId_idx" ON public."AuditLog" USING btree ("userId");


--
-- Name: Message_createdAt_idx; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE INDEX "Message_createdAt_idx" ON public."Message" USING btree ("createdAt");


--
-- Name: Message_senderId_receiverId_idx; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE INDEX "Message_senderId_receiverId_idx" ON public."Message" USING btree ("senderId", "receiverId");


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_googleId_key; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE UNIQUE INDEX "User_googleId_key" ON public."User" USING btree ("googleId");


--
-- Name: User_inviteToken_key; Type: INDEX; Schema: public; Owner: mapeople
--

CREATE UNIQUE INDEX "User_inviteToken_key" ON public."User" USING btree ("inviteToken");


--
-- Name: AuditLog AuditLog_residentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_residentId_fkey" FOREIGN KEY ("residentId") REFERENCES public."Resident"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_receiverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Resident Resident_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."Resident"
    ADD CONSTRAINT "Resident_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Resident Resident_updatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mapeople
--

ALTER TABLE ONLY public."Resident"
    ADD CONSTRAINT "Resident_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 6vZ6iekleMzCJPlkHYuBf6h1mhh5qiSkIkMQjhi2WYyO4SSCAhKAgdKh8L8hlnu

